package com.example.demo;

import java.time.LocalDate;

public class Show {
    private int id;
    private String namaShow;
    private String namaKota;
    private LocalDate tanggalAcara;
    private String waktuMulai;

    // Constructor
    public Show(int id, String namaShow, String namaKota, LocalDate tanggalAcara, String waktuMulai) {
        this.id = id;
        this.namaShow = namaShow;
        this.namaKota = namaKota;
        this.tanggalAcara = tanggalAcara;
        this.waktuMulai = waktuMulai;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNamaShow() {
        return namaShow;
    }

    public void setNamaShow(String namaShow) {
        this.namaShow = namaShow;
    }

    public String getNamaKota() {
        return namaKota;
    }

    public void setNamaKota(String namaKota) {
        this.namaKota = namaKota;
    }

    public LocalDate getTanggalAcara() {
        return tanggalAcara;
    }

    public void setTanggalAcara(LocalDate tanggalAcara) {
        this.tanggalAcara = tanggalAcara;
    }

    public String getWaktuMulai() {
        return waktuMulai;
    }

    public void setWaktuMulai(String waktuMulai) {
        this.waktuMulai = waktuMulai;
    }
}
