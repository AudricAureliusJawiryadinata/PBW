package com.example.demo.Artis;

import java.util.List;

public interface ArtistRepository {
    List<Artist> findAllArtists();
    List<Artist> findByNameContainingIgnoreCase(String name);
    List<Artist> findArtistsByShow(String namaShow);
    String getArtisNameById(int artisId);
}
