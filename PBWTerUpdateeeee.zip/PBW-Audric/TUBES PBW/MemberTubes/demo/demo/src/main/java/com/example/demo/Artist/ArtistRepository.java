package com.example.demo.Artist;

import java.util.List;

public interface ArtistRepository {
    List<Artist> findAllArtists();
}
