package com.example.demo.Guest;

public class JdbcGuestRepository {
    
}
