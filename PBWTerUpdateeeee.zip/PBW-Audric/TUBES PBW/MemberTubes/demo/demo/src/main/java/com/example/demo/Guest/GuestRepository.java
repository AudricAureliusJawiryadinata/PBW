package com.example.demo.Guest;

public interface GuestRepository {
    
}
